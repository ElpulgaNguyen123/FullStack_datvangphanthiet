var express = require('express');
var adminRouter = express.Router();
var { validateRegister, validateEmailResetpassword, validateChangePassword } = require('../validator');
var controller = require('../model/controllers/admin');
var passport = require('passport');
var { initPassportLocal } = require('../model/controllers/admin/passportController');
const admin = require('../model/controllers/admin');

initPassportLocal();
// authencation ===============
adminRouter.get('/login', controller.checkloggedOut, controller.loginController);
adminRouter.post('/login', controller.checkloggedOut, passport.authenticate('local', {
  successRedirect: '/admin',
  failureRedirect: '/admin/login',
  failureFlash: 'Người dùng không tồn tại !',
  successFlash: 'Chào mừng !',
}));

// authencation =============
adminRouter.get('/logout', controller.checkloggedIn, controller.getLogout);
adminRouter.get('/register', controller.registerController);
adminRouter.post('/register', controller.checkloggedOut, validateRegister, controller.PostRegisterController);
adminRouter.get('/reset-password', controller.checkloggedOut, controller.resetPasswordController);
adminRouter.post('/reset-password', controller.checkloggedOut, validateEmailResetpassword, controller.PostResetPasswordController);
adminRouter.get('/reset-password/:token', controller.checkloggedOut, controller.resetPasswordGetToken);
adminRouter.get('/change-password/:token', controller.checkloggedOut, controller.changePasswordController);
adminRouter.post('/change-password/:token', controller.checkloggedOut, validateChangePassword, controller.changePassword)
// authencation / end =============

// userupdate data ===========
adminRouter.get('/user/:id', controller.checkloggedIn, controller.getUser);
adminRouter.post('/update-user/:id', controller.checkloggedIn, controller.updateUserData);
adminRouter.post('/update-avatar/:id', controller.checkloggedIn, controller.updateUserAvatar);
// userupdate data ===========

adminRouter.get('/', controller.checkloggedIn, controller.homeController);
// products router
adminRouter.get('/products', controller.checkloggedIn, controller.getAllProduct);
adminRouter.get('/products/add-product', controller.checkloggedIn, controller.addProductGet);
adminRouter.post('/product/add-product-image', controller.checkloggedIn, controller.addProductImage);
adminRouter.post('/products/add-product', controller.checkloggedIn, controller.addProductPost);
adminRouter.get('/product/edit-product/:id', controller.checkloggedIn, controller.editProductGet);
adminRouter.post('/product/edit-product/:id', controller.checkloggedIn, controller.editProductPost);
adminRouter.post('/product/add-product-attribute/:id', controller.checkloggedIn, controller.addProductAttribute);
adminRouter.get('/product/edit-product-image/:id', controller.checkloggedIn, controller.editProductImage);
adminRouter.post('/product/edit-product-image/:id', controller.checkloggedIn, controller.updateProductImagePost);
adminRouter.get('/product/delete-product-image/:id', controller.checkloggedIn, controller.deleteProductImage);
adminRouter.get('/product-category/:idcategory', controller.checkloggedIn, controller.getAllProductCategory);
adminRouter.get('/product-location/:idlocation', controller.checkloggedIn, controller.getAllProductLocation);
adminRouter.get('/products/giam-dan', controller.checkloggedIn, controller.getAllProductDesc);
adminRouter.get('/product/search/:name', controller.checkloggedIn, controller.searchData);
adminRouter.get('/product/delete-product/:iddelete', controller.checkloggedIn, controller.deleteProductController);
adminRouter.post('/product/get-more/:page', controller.checkloggedIn, controller.getPageLoad);
adminRouter.post('/product/check-sku', controller.checkloggedIn, controller.checkSkuMatch);
// products router // end


// project router // start
adminRouter.get('/projects', controller.checkloggedIn, controller.getAllProject);
adminRouter.get('/project/add-project', controller.checkloggedIn, controller.addProjectGet);
adminRouter.post('/project/add-project', controller.checkloggedIn, controller.addProjectPost);
adminRouter.post('/project/add-project-image', controller.checkloggedIn, controller.addProjectImage);
adminRouter.post('/project/check-sku', controller.checkloggedIn,controller.checkSkuMatchProject);
adminRouter.post('/project/get-more/:page', controller.checkloggedIn, controller.getProjectPageLoad);
adminRouter.get('/project/search/:name', controller.checkloggedIn, controller.searchDataProject);
adminRouter.get('/project/edit-project/:id', controller.checkloggedIn, controller.editProjectGet);
adminRouter.post('/project/edit-project/:id', controller.checkloggedIn, controller.editProjectPost);
adminRouter.get('/project/edit-project-image/:id', controller.checkloggedIn, controller.editProjectImage);
adminRouter.post('/project/edit-project-image/:id', controller.checkloggedIn, controller.updateProjectImagePost);
adminRouter.get('/project/delete-project-image/:id', controller.checkloggedIn, controller.deleteProjectImage);
adminRouter.get('/project/delete-project/:iddelete', controller.checkloggedIn, controller.deleteProjectController);
adminRouter.get('/project/giam-dan', controller.checkloggedIn, controller.getAllProjectDesc);


// project router // end

// attribute start
adminRouter.get('/attributes', controller.checkloggedIn, controller.getAllAttribute);
adminRouter.post('/attribute/add-attribute', controller.checkloggedIn, controller.postAddAttribute);
adminRouter.get('/attribute/edit-attribute/:id', controller.checkloggedIn, controller.getEditAttribute);
adminRouter.post('/attribute/edit-attribute/:id', controller.checkloggedIn, controller.postEditAttribute);
adminRouter.get('/attribute/delete-attribute/:id', controller.checkloggedIn, controller.postDeleteAttribute);
// attribute end

// attribute value // start
adminRouter.post('/attribute/edit-attribute-value/:id', controller.checkloggedIn, controller.postAddAttributeValue);
adminRouter.get('/attribute/delete-attribute-value/:id', controller.checkloggedIn, controller.postDeleteAttributeValue);
// attribute value // end

//brand start
// adminRouter.get('/brands', controller.checkloggedIn, controller.getAllBrand);
// adminRouter.post('/brand/add-brand', controller.checkloggedIn, controller.addBrandImage);
// adminRouter.get('/brand/edit-brand/:id', controller.checkloggedIn, controller.getEditBrand);
// adminRouter.post('/brand/edit-brand/:id', controller.checkloggedIn, controller.postEditBrand);
// adminRouter.get('/brand/delete-brand/:id', controller.checkloggedIn, controller.postDeleteBrand);
//brand end

//brand start
adminRouter.get('/categories', controller.checkloggedIn, controller.getAllCategories);
adminRouter.post('/category/add-category', controller.checkloggedIn, controller.addCategory);
adminRouter.get('/category/edit-category/:id', controller.checkloggedIn, controller.getEditCategory);
adminRouter.post('/category/edit-category/:id', controller.checkloggedIn, controller.postEditCategory);
adminRouter.get('/category/delete-category/:id', controller.checkloggedIn, controller.DeleteCategory);
//brand end

/*=============================================
=            Website template / start        =
=============================================*/

// slider /start ==============================================
adminRouter.get('/slides', controller.checkloggedIn, controller.getAllSlide);
adminRouter.post('/slide/add-slide', controller.checkloggedIn, controller.addSlide);
adminRouter.get('/slide/edit-slide/:id', controller.checkloggedIn, controller.getEditSlide);
adminRouter.post('/slide/edit-slide/:id', controller.checkloggedIn, controller.postEditSlide);
adminRouter.get('/slide/delete-slide/:id', controller.checkloggedIn, controller.postDeleteSlide);
// slider / end ==============================================

// Blog / start
adminRouter.get('/blog', controller.checkloggedIn, controller.getAllBlog);
adminRouter.get('/blog/add-blog', controller.checkloggedIn, controller.addBlogGet);
adminRouter.post('/blog/add-blog', controller.checkloggedIn, controller.addBlogPost);
adminRouter.get('/blog/edit-blog/:id', controller.checkloggedIn, controller.getEditBlog);
adminRouter.post('/blog/edit-blog/:id', controller.checkloggedIn, controller.postEditBlog);
adminRouter.get('/blog/delete-blog/:id', controller.checkloggedIn, controller.postDeleteBlog);

adminRouter.get('/blog-categories', controller.checkloggedIn, controller.getAllBlogCategory);
adminRouter.get('/blog-category/add-blog-category', controller.checkloggedIn, controller.addBlogCategoryGet);
adminRouter.post('/blog-category/add-blog-category', controller.checkloggedIn, controller.addBlogCategoryPost);
adminRouter.post('/blog-category/edit-blog-category/:id', controller.checkloggedIn, controller.editBlogCategoryPost);
adminRouter.get('/blog-category/edit-blog-category/:id', controller.checkloggedIn, controller.editBlogCategoryGet);
adminRouter.get('/blog-category/delete-blog-category/:id', controller.checkloggedIn, controller.postDeleteBlogCategory);
// Blog / end

// endow / start
adminRouter.get('/endow', controller.checkloggedIn, controller.getAllEndow);
adminRouter.get('/endow/add-endow', controller.checkloggedIn, controller.addEndowGet);
adminRouter.post('/endow/add-endow', controller.checkloggedIn, controller.addEndowPost);
adminRouter.get('/endow/edit-endow/:id', controller.checkloggedIn, controller.getEditEndow);
adminRouter.post('/endow/edit-endow/:id', controller.checkloggedIn, controller.postEditEndow);
// endow / end

// company-feature / start
adminRouter.get('/company-features', controller.checkloggedIn, controller.getAllFeatureCompany);
adminRouter.get('/company-feature/add-company-feature', controller.checkloggedIn, controller.addFeatureCompanyGet);
adminRouter.post('/company-feature/add-company-feature', controller.checkloggedIn, controller.addFeatureCompanyPost);
adminRouter.get('/company-feature/edit-company-feature/:id', controller.checkloggedIn, controller.getFeatureCompanyEndow);
adminRouter.post('/company-feature/edit-company-feature/:id', controller.checkloggedIn, controller.postFeatureCompanyEndow);
// company-feature / end


// customer / start
adminRouter.get('/customers', controller.checkloggedIn, controller.getAllCustomeController);
adminRouter.get('/customer/add-customer', controller.checkloggedIn, controller.addCustomerGetController);
adminRouter.post('/customer/add-customer', controller.checkloggedIn, controller.addCustomerPostController);
adminRouter.get('/customer/edit-customer/:id', controller.checkloggedIn, controller.getEditCustomerController);
adminRouter.post('/customer/edit-customer/:id', controller.checkloggedIn, controller.postEditCustomerController);
adminRouter.get('/customer/delete-customer/:id', controller.checkloggedIn, controller.deleteCustomerController);
// customer / end


// policies / start
adminRouter.get('/policies', controller.checkloggedIn, controller.getAllPolicy);
adminRouter.get('/policy/add-policy', controller.checkloggedIn, controller.addPolicyGet);
adminRouter.post('/policy/add-policy', controller.checkloggedIn, controller.addPolicyPost);
adminRouter.get('/policy/edit-policy/:id', controller.checkloggedIn, controller.getEditPolicy);
adminRouter.post('/policy/edit-policy/:id', controller.checkloggedIn, controller.postEditPolicy);
adminRouter.get('/policy/delete-policy/:id', controller.checkloggedIn, controller.postDeletePolicy);
// policies / end

// staff / start
adminRouter.get('/staffs', controller.checkloggedIn, controller.getAllStaff);
adminRouter.get('/staff/add-staff', controller.checkloggedIn, controller.addStaffGet);
adminRouter.post('/staff/add-staff', controller.checkloggedIn, controller.addStaffPost);
adminRouter.get('/staff/edit-staff/:id', controller.checkloggedIn, controller.getEditStaff);
adminRouter.post('/staff/edit-staff/:id', controller.checkloggedIn, controller.postEditStaff);
adminRouter.get('/staff/delete-staff/:id', controller.checkloggedIn, controller.postDeleteStaff);

// staff / end

/*=====   Website template / end  ======*/
adminRouter.use((req, res, next) => {
  res.render('admin/notfound/notfound', {
    title: 'Trang Không tìm thấy'
  });
})


module.exports = adminRouter; 